﻿namespace Crucero
{
    partial class ProyectoFinal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProyectoFinal));
            this.lblSevenSeas = new System.Windows.Forms.Label();
            this.picBeach = new System.Windows.Forms.PictureBox();
            this.picIcon = new System.Windows.Forms.PictureBox();
            this.txtbxSearch = new System.Windows.Forms.TextBox();
            this.picSearch = new System.Windows.Forms.PictureBox();
            this.picBorderMenu = new System.Windows.Forms.PictureBox();
            this.btnCrucerosDisponibles = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblCuando = new System.Windows.Forms.Label();
            this.calCalendario = new System.Windows.Forms.DateTimePicker();
            this.lblDonde = new System.Windows.Forms.Label();
            this.cmbDestinos = new System.Windows.Forms.ComboBox();
            this.txtbxReservarCruc = new System.Windows.Forms.TextBox();
            this.lblReservarCrucero = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtbxNumTarjeta = new System.Windows.Forms.TextBox();
            this.lblNumPasajeros = new System.Windows.Forms.Label();
            this.txtbxNumPasajeros = new System.Windows.Forms.TextBox();
            this.btnFiltrar = new System.Windows.Forms.Button();
            this.lblNumTarjeta = new System.Windows.Forms.Label();
            this.txtbxNombre = new System.Windows.Forms.TextBox();
            this.lblConfirmacion = new System.Windows.Forms.Label();
            this.lblListaCruceros = new System.Windows.Forms.Label();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lstbxLista = new System.Windows.Forms.ListBox();
            this.lstbxConfirmacion = new System.Windows.Forms.ListBox();
            this.chkboxFecha = new System.Windows.Forms.CheckBox();
            this.btnReservar = new System.Windows.Forms.Button();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabUsuario = new System.Windows.Forms.TabPage();
            this.tabAdmin = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.lstbxListaBajaA = new System.Windows.Forms.ListBox();
            this.lblDardeBajaA = new System.Windows.Forms.Label();
            this.btnGuardarA = new System.Windows.Forms.Button();
            this.lblResActualesA = new System.Windows.Forms.Label();
            this.calRegresoA = new System.Windows.Forms.DateTimePicker();
            this.calSalidaA = new System.Windows.Forms.DateTimePicker();
            this.lblDardeAltaA = new System.Windows.Forms.Label();
            this.txtbxMaxPersonasA = new System.Windows.Forms.TextBox();
            this.lblMaxPersonasA = new System.Windows.Forms.Label();
            this.txtbxIDA = new System.Windows.Forms.TextBox();
            this.lblIDA = new System.Windows.Forms.Label();
            this.txtbxPuertoA = new System.Windows.Forms.TextBox();
            this.lblPuertoA = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblFechaSalidaA = new System.Windows.Forms.Label();
            this.txtbxCostoA = new System.Windows.Forms.TextBox();
            this.lblCostoA = new System.Windows.Forms.Label();
            this.txtbxDestinoA = new System.Windows.Forms.TextBox();
            this.lblDestinoA = new System.Windows.Forms.Label();
            this.txtbxResActualesA = new System.Windows.Forms.TextBox();
            this.btnUsuario = new System.Windows.Forms.Button();
            this.picBanda = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBeach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorderMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabUsuario.SuspendLayout();
            this.tabAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBanda)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSevenSeas
            // 
            this.lblSevenSeas.AutoSize = true;
            this.lblSevenSeas.Font = new System.Drawing.Font("Avenir", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSevenSeas.ForeColor = System.Drawing.Color.Navy;
            this.lblSevenSeas.Location = new System.Drawing.Point(49, 7);
            this.lblSevenSeas.Name = "lblSevenSeas";
            this.lblSevenSeas.Size = new System.Drawing.Size(221, 49);
            this.lblSevenSeas.TabIndex = 0;
            this.lblSevenSeas.Text = "Seven Seas";
            // 
            // picBeach
            // 
            this.picBeach.Image = ((System.Drawing.Image)(resources.GetObject("picBeach.Image")));
            this.picBeach.Location = new System.Drawing.Point(0, 34);
            this.picBeach.Name = "picBeach";
            this.picBeach.Size = new System.Drawing.Size(737, 263);
            this.picBeach.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBeach.TabIndex = 1;
            this.picBeach.TabStop = false;
            // 
            // picIcon
            // 
            this.picIcon.Image = ((System.Drawing.Image)(resources.GetObject("picIcon.Image")));
            this.picIcon.Location = new System.Drawing.Point(2, 12);
            this.picIcon.Name = "picIcon";
            this.picIcon.Size = new System.Drawing.Size(52, 44);
            this.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picIcon.TabIndex = 2;
            this.picIcon.TabStop = false;
            // 
            // txtbxSearch
            // 
            this.txtbxSearch.Location = new System.Drawing.Point(553, 28);
            this.txtbxSearch.Name = "txtbxSearch";
            this.txtbxSearch.Size = new System.Drawing.Size(156, 20);
            this.txtbxSearch.TabIndex = 3;
            // 
            // picSearch
            // 
            this.picSearch.Image = ((System.Drawing.Image)(resources.GetObject("picSearch.Image")));
            this.picSearch.Location = new System.Drawing.Point(713, 29);
            this.picSearch.Name = "picSearch";
            this.picSearch.Size = new System.Drawing.Size(17, 15);
            this.picSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSearch.TabIndex = 4;
            this.picSearch.TabStop = false;
            // 
            // picBorderMenu
            // 
            this.picBorderMenu.Image = ((System.Drawing.Image)(resources.GetObject("picBorderMenu.Image")));
            this.picBorderMenu.Location = new System.Drawing.Point(0, 0);
            this.picBorderMenu.Name = "picBorderMenu";
            this.picBorderMenu.Size = new System.Drawing.Size(730, 31);
            this.picBorderMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBorderMenu.TabIndex = 5;
            this.picBorderMenu.TabStop = false;
            // 
            // btnCrucerosDisponibles
            // 
            this.btnCrucerosDisponibles.BackColor = System.Drawing.Color.Transparent;
            this.btnCrucerosDisponibles.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCrucerosDisponibles.BackgroundImage")));
            this.btnCrucerosDisponibles.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCrucerosDisponibles.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrucerosDisponibles.ForeColor = System.Drawing.Color.White;
            this.btnCrucerosDisponibles.Location = new System.Drawing.Point(-4, 0);
            this.btnCrucerosDisponibles.Margin = new System.Windows.Forms.Padding(0);
            this.btnCrucerosDisponibles.Name = "btnCrucerosDisponibles";
            this.btnCrucerosDisponibles.Size = new System.Drawing.Size(242, 31);
            this.btnCrucerosDisponibles.TabIndex = 6;
            this.btnCrucerosDisponibles.Text = "Ver cruceros disponibles";
            this.btnCrucerosDisponibles.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCrucerosDisponibles.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnCrucerosDisponibles.UseVisualStyleBackColor = false;
            this.btnCrucerosDisponibles.Click += new System.EventHandler(this.btnCrucerosDisponibles_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(204, 120);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(391, 95);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // lblCuando
            // 
            this.lblCuando.AutoSize = true;
            this.lblCuando.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuando.Location = new System.Drawing.Point(216, 124);
            this.lblCuando.Name = "lblCuando";
            this.lblCuando.Size = new System.Drawing.Size(74, 19);
            this.lblCuando.TabIndex = 9;
            this.lblCuando.Text = "¿Cuándo?";
            // 
            // calCalendario
            // 
            this.calCalendario.CustomFormat = "";
            this.calCalendario.Enabled = false;
            this.calCalendario.Location = new System.Drawing.Point(220, 146);
            this.calCalendario.Name = "calCalendario";
            this.calCalendario.Size = new System.Drawing.Size(198, 20);
            this.calCalendario.TabIndex = 10;
            // 
            // lblDonde
            // 
            this.lblDonde.AutoSize = true;
            this.lblDonde.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDonde.Location = new System.Drawing.Point(434, 124);
            this.lblDonde.Name = "lblDonde";
            this.lblDonde.Size = new System.Drawing.Size(79, 19);
            this.lblDonde.TabIndex = 11;
            this.lblDonde.Text = "¿A dónde?";
            // 
            // cmbDestinos
            // 
            this.cmbDestinos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDestinos.FormattingEnabled = true;
            this.cmbDestinos.Location = new System.Drawing.Point(438, 145);
            this.cmbDestinos.Name = "cmbDestinos";
            this.cmbDestinos.Size = new System.Drawing.Size(128, 21);
            this.cmbDestinos.TabIndex = 12;
            // 
            // txtbxReservarCruc
            // 
            this.txtbxReservarCruc.Enabled = false;
            this.txtbxReservarCruc.Location = new System.Drawing.Point(330, 354);
            this.txtbxReservarCruc.Name = "txtbxReservarCruc";
            this.txtbxReservarCruc.Size = new System.Drawing.Size(141, 20);
            this.txtbxReservarCruc.TabIndex = 15;
            // 
            // lblReservarCrucero
            // 
            this.lblReservarCrucero.AutoSize = true;
            this.lblReservarCrucero.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReservarCrucero.Location = new System.Drawing.Point(330, 333);
            this.lblReservarCrucero.Name = "lblReservarCrucero";
            this.lblReservarCrucero.Size = new System.Drawing.Size(115, 18);
            this.lblReservarCrucero.TabIndex = 16;
            this.lblReservarCrucero.Text = "Reservar crucero:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(333, 439);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(121, 18);
            this.lblNombre.TabIndex = 18;
            this.lblNombre.Text = "Huésped principal:";
            // 
            // txtbxNumTarjeta
            // 
            this.txtbxNumTarjeta.Location = new System.Drawing.Point(330, 504);
            this.txtbxNumTarjeta.Name = "txtbxNumTarjeta";
            this.txtbxNumTarjeta.Size = new System.Drawing.Size(141, 20);
            this.txtbxNumTarjeta.TabIndex = 17;
            // 
            // lblNumPasajeros
            // 
            this.lblNumPasajeros.AutoSize = true;
            this.lblNumPasajeros.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumPasajeros.Location = new System.Drawing.Point(330, 377);
            this.lblNumPasajeros.Name = "lblNumPasajeros";
            this.lblNumPasajeros.Size = new System.Drawing.Size(141, 18);
            this.lblNumPasajeros.TabIndex = 20;
            this.lblNumPasajeros.Text = "Número de pasajeros:";
            // 
            // txtbxNumPasajeros
            // 
            this.txtbxNumPasajeros.Location = new System.Drawing.Point(330, 398);
            this.txtbxNumPasajeros.MaxLength = 3;
            this.txtbxNumPasajeros.Name = "txtbxNumPasajeros";
            this.txtbxNumPasajeros.Size = new System.Drawing.Size(141, 20);
            this.txtbxNumPasajeros.TabIndex = 19;
            this.txtbxNumPasajeros.TextChanged += new System.EventHandler(this.txtbxNumPasajeros_TextChanged);
            // 
            // btnFiltrar
            // 
            this.btnFiltrar.BackColor = System.Drawing.Color.Transparent;
            this.btnFiltrar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFiltrar.BackgroundImage")));
            this.btnFiltrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFiltrar.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFiltrar.ForeColor = System.Drawing.Color.White;
            this.btnFiltrar.Location = new System.Drawing.Point(338, 169);
            this.btnFiltrar.Margin = new System.Windows.Forms.Padding(0);
            this.btnFiltrar.Name = "btnFiltrar";
            this.btnFiltrar.Size = new System.Drawing.Size(118, 31);
            this.btnFiltrar.TabIndex = 21;
            this.btnFiltrar.Text = "Filtrar";
            this.btnFiltrar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnFiltrar.UseVisualStyleBackColor = false;
            this.btnFiltrar.Click += new System.EventHandler(this.btnFiltrar_Click);
            // 
            // lblNumTarjeta
            // 
            this.lblNumTarjeta.AutoSize = true;
            this.lblNumTarjeta.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumTarjeta.Location = new System.Drawing.Point(331, 483);
            this.lblNumTarjeta.Name = "lblNumTarjeta";
            this.lblNumTarjeta.Size = new System.Drawing.Size(123, 18);
            this.lblNumTarjeta.TabIndex = 23;
            this.lblNumTarjeta.Text = "Número de tarjeta:";
            // 
            // txtbxNombre
            // 
            this.txtbxNombre.Location = new System.Drawing.Point(330, 460);
            this.txtbxNombre.Name = "txtbxNombre";
            this.txtbxNombre.Size = new System.Drawing.Size(141, 20);
            this.txtbxNombre.TabIndex = 22;
            // 
            // lblConfirmacion
            // 
            this.lblConfirmacion.AutoSize = true;
            this.lblConfirmacion.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmacion.Location = new System.Drawing.Point(492, 301);
            this.lblConfirmacion.Name = "lblConfirmacion";
            this.lblConfirmacion.Size = new System.Drawing.Size(95, 18);
            this.lblConfirmacion.TabIndex = 24;
            this.lblConfirmacion.Text = "Confirmación:";
            // 
            // lblListaCruceros
            // 
            this.lblListaCruceros.AutoSize = true;
            this.lblListaCruceros.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListaCruceros.Location = new System.Drawing.Point(9, 301);
            this.lblListaCruceros.Name = "lblListaCruceros";
            this.lblListaCruceros.Size = new System.Drawing.Size(115, 18);
            this.lblListaCruceros.TabIndex = 26;
            this.lblListaCruceros.Text = "Lista de cruceros:";
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCosto.Location = new System.Drawing.Point(347, 421);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(47, 18);
            this.lblCosto.TabIndex = 27;
            this.lblCosto.Text = "$ 0.00";
            this.lblCosto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lstbxLista
            // 
            this.lstbxLista.FormattingEnabled = true;
            this.lstbxLista.HorizontalScrollbar = true;
            this.lstbxLista.Location = new System.Drawing.Point(12, 325);
            this.lstbxLista.Name = "lstbxLista";
            this.lstbxLista.Size = new System.Drawing.Size(299, 199);
            this.lstbxLista.TabIndex = 28;
            this.lstbxLista.SelectedIndexChanged += new System.EventHandler(this.lstbxLista_SelectedIndexChanged);
            // 
            // lstbxConfirmacion
            // 
            this.lstbxConfirmacion.FormattingEnabled = true;
            this.lstbxConfirmacion.HorizontalScrollbar = true;
            this.lstbxConfirmacion.Location = new System.Drawing.Point(495, 325);
            this.lstbxConfirmacion.Name = "lstbxConfirmacion";
            this.lstbxConfirmacion.Size = new System.Drawing.Size(211, 199);
            this.lstbxConfirmacion.TabIndex = 29;
            // 
            // chkboxFecha
            // 
            this.chkboxFecha.AutoSize = true;
            this.chkboxFecha.Location = new System.Drawing.Point(296, 129);
            this.chkboxFecha.Name = "chkboxFecha";
            this.chkboxFecha.Size = new System.Drawing.Size(15, 14);
            this.chkboxFecha.TabIndex = 30;
            this.chkboxFecha.UseVisualStyleBackColor = true;
            this.chkboxFecha.CheckedChanged += new System.EventHandler(this.chkboxFecha_CheckedChanged);
            // 
            // btnReservar
            // 
            this.btnReservar.BackColor = System.Drawing.Color.Transparent;
            this.btnReservar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReservar.BackgroundImage")));
            this.btnReservar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnReservar.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReservar.ForeColor = System.Drawing.Color.White;
            this.btnReservar.Location = new System.Drawing.Point(350, 536);
            this.btnReservar.Margin = new System.Windows.Forms.Padding(0);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(118, 31);
            this.btnReservar.TabIndex = 31;
            this.btnReservar.Text = "Reservar";
            this.btnReservar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnReservar.UseVisualStyleBackColor = false;
            this.btnReservar.Click += new System.EventHandler(this.btnReservar_Click);
            // 
            // btnAdmin
            // 
            this.btnAdmin.BackColor = System.Drawing.Color.Transparent;
            this.btnAdmin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdmin.BackgroundImage")));
            this.btnAdmin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAdmin.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmin.ForeColor = System.Drawing.Color.White;
            this.btnAdmin.Location = new System.Drawing.Point(599, 0);
            this.btnAdmin.Margin = new System.Windows.Forms.Padding(0);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(118, 31);
            this.btnAdmin.TabIndex = 32;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnAdmin.UseVisualStyleBackColor = false;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabUsuario);
            this.tabControl1.Controls.Add(this.tabAdmin);
            this.tabControl1.Location = new System.Drawing.Point(2, 35);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(0, 0);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(741, 611);
            this.tabControl1.TabIndex = 33;
            // 
            // tabUsuario
            // 
            this.tabUsuario.BackColor = System.Drawing.SystemColors.Control;
            this.tabUsuario.Controls.Add(this.lblNumPasajeros);
            this.tabUsuario.Controls.Add(this.lblCosto);
            this.tabUsuario.Controls.Add(this.btnReservar);
            this.tabUsuario.Controls.Add(this.txtbxNombre);
            this.tabUsuario.Controls.Add(this.lblNombre);
            this.tabUsuario.Controls.Add(this.lblNumTarjeta);
            this.tabUsuario.Controls.Add(this.btnAdmin);
            this.tabUsuario.Controls.Add(this.lstbxConfirmacion);
            this.tabUsuario.Controls.Add(this.lblConfirmacion);
            this.tabUsuario.Controls.Add(this.chkboxFecha);
            this.tabUsuario.Controls.Add(this.txtbxNumTarjeta);
            this.tabUsuario.Controls.Add(this.lstbxLista);
            this.tabUsuario.Controls.Add(this.txtbxNumPasajeros);
            this.tabUsuario.Controls.Add(this.lblListaCruceros);
            this.tabUsuario.Controls.Add(this.btnCrucerosDisponibles);
            this.tabUsuario.Controls.Add(this.picBorderMenu);
            this.tabUsuario.Controls.Add(this.lblCuando);
            this.tabUsuario.Controls.Add(this.calCalendario);
            this.tabUsuario.Controls.Add(this.btnFiltrar);
            this.tabUsuario.Controls.Add(this.lblDonde);
            this.tabUsuario.Controls.Add(this.txtbxReservarCruc);
            this.tabUsuario.Controls.Add(this.lblReservarCrucero);
            this.tabUsuario.Controls.Add(this.cmbDestinos);
            this.tabUsuario.Controls.Add(this.pictureBox1);
            this.tabUsuario.Controls.Add(this.picBeach);
            this.tabUsuario.Location = new System.Drawing.Point(4, 22);
            this.tabUsuario.Name = "tabUsuario";
            this.tabUsuario.Padding = new System.Windows.Forms.Padding(3);
            this.tabUsuario.Size = new System.Drawing.Size(733, 585);
            this.tabUsuario.TabIndex = 0;
            this.tabUsuario.Text = "Usuario";
            // 
            // tabAdmin
            // 
            this.tabAdmin.BackColor = System.Drawing.SystemColors.Control;
            this.tabAdmin.Controls.Add(this.button1);
            this.tabAdmin.Controls.Add(this.lstbxListaBajaA);
            this.tabAdmin.Controls.Add(this.lblDardeBajaA);
            this.tabAdmin.Controls.Add(this.btnGuardarA);
            this.tabAdmin.Controls.Add(this.lblResActualesA);
            this.tabAdmin.Controls.Add(this.calRegresoA);
            this.tabAdmin.Controls.Add(this.calSalidaA);
            this.tabAdmin.Controls.Add(this.lblDardeAltaA);
            this.tabAdmin.Controls.Add(this.txtbxMaxPersonasA);
            this.tabAdmin.Controls.Add(this.lblMaxPersonasA);
            this.tabAdmin.Controls.Add(this.txtbxIDA);
            this.tabAdmin.Controls.Add(this.lblIDA);
            this.tabAdmin.Controls.Add(this.txtbxPuertoA);
            this.tabAdmin.Controls.Add(this.lblPuertoA);
            this.tabAdmin.Controls.Add(this.label1);
            this.tabAdmin.Controls.Add(this.lblFechaSalidaA);
            this.tabAdmin.Controls.Add(this.txtbxCostoA);
            this.tabAdmin.Controls.Add(this.lblCostoA);
            this.tabAdmin.Controls.Add(this.txtbxDestinoA);
            this.tabAdmin.Controls.Add(this.lblDestinoA);
            this.tabAdmin.Controls.Add(this.txtbxResActualesA);
            this.tabAdmin.Controls.Add(this.btnUsuario);
            this.tabAdmin.Controls.Add(this.picBanda);
            this.tabAdmin.Location = new System.Drawing.Point(4, 22);
            this.tabAdmin.Name = "tabAdmin";
            this.tabAdmin.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdmin.Size = new System.Drawing.Size(733, 591);
            this.tabAdmin.TabIndex = 1;
            this.tabAdmin.Text = "Admin";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(15, 403);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 31);
            this.button1.TabIndex = 57;
            this.button1.Text = "Guardar";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // lstbxListaBajaA
            // 
            this.lstbxListaBajaA.FormattingEnabled = true;
            this.lstbxListaBajaA.HorizontalScrollbar = true;
            this.lstbxListaBajaA.Location = new System.Drawing.Point(12, 277);
            this.lstbxListaBajaA.Name = "lstbxListaBajaA";
            this.lstbxListaBajaA.Size = new System.Drawing.Size(582, 108);
            this.lstbxListaBajaA.TabIndex = 56;
            // 
            // lblDardeBajaA
            // 
            this.lblDardeBajaA.AutoSize = true;
            this.lblDardeBajaA.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDardeBajaA.Location = new System.Drawing.Point(8, 255);
            this.lblDardeBajaA.Name = "lblDardeBajaA";
            this.lblDardeBajaA.Size = new System.Drawing.Size(172, 19);
            this.lblDardeBajaA.TabIndex = 55;
            this.lblDardeBajaA.Text = "Dar de BAJA un Crucero";
            // 
            // btnGuardarA
            // 
            this.btnGuardarA.BackColor = System.Drawing.Color.Transparent;
            this.btnGuardarA.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGuardarA.BackgroundImage")));
            this.btnGuardarA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnGuardarA.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarA.ForeColor = System.Drawing.Color.White;
            this.btnGuardarA.Location = new System.Drawing.Point(12, 209);
            this.btnGuardarA.Margin = new System.Windows.Forms.Padding(0);
            this.btnGuardarA.Name = "btnGuardarA";
            this.btnGuardarA.Size = new System.Drawing.Size(118, 31);
            this.btnGuardarA.TabIndex = 54;
            this.btnGuardarA.Text = "Guardar";
            this.btnGuardarA.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnGuardarA.UseVisualStyleBackColor = false;
            this.btnGuardarA.Click += new System.EventHandler(this.btnGuardarA_Click);
            // 
            // lblResActualesA
            // 
            this.lblResActualesA.AutoSize = true;
            this.lblResActualesA.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResActualesA.Location = new System.Drawing.Point(8, 451);
            this.lblResActualesA.Name = "lblResActualesA";
            this.lblResActualesA.Size = new System.Drawing.Size(196, 19);
            this.lblResActualesA.TabIndex = 53;
            this.lblResActualesA.Text = "Ver Reservaciones Actuales";
            // 
            // calRegresoA
            // 
            this.calRegresoA.CustomFormat = "";
            this.calRegresoA.Location = new System.Drawing.Point(278, 131);
            this.calRegresoA.Name = "calRegresoA";
            this.calRegresoA.Size = new System.Drawing.Size(198, 20);
            this.calRegresoA.TabIndex = 52;
            // 
            // calSalidaA
            // 
            this.calSalidaA.CustomFormat = "";
            this.calSalidaA.Location = new System.Drawing.Point(15, 131);
            this.calSalidaA.Name = "calSalidaA";
            this.calSalidaA.Size = new System.Drawing.Size(198, 20);
            this.calSalidaA.TabIndex = 51;
            // 
            // lblDardeAltaA
            // 
            this.lblDardeAltaA.AutoSize = true;
            this.lblDardeAltaA.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDardeAltaA.Location = new System.Drawing.Point(8, 36);
            this.lblDardeAltaA.Name = "lblDardeAltaA";
            this.lblDardeAltaA.Size = new System.Drawing.Size(170, 19);
            this.lblDardeAltaA.TabIndex = 50;
            this.lblDardeAltaA.Text = "Dar de ALTA un Crucero";
            // 
            // txtbxMaxPersonasA
            // 
            this.txtbxMaxPersonasA.Location = new System.Drawing.Point(149, 175);
            this.txtbxMaxPersonasA.Name = "txtbxMaxPersonasA";
            this.txtbxMaxPersonasA.Size = new System.Drawing.Size(100, 20);
            this.txtbxMaxPersonasA.TabIndex = 49;
            // 
            // lblMaxPersonasA
            // 
            this.lblMaxPersonasA.AutoSize = true;
            this.lblMaxPersonasA.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaxPersonasA.Location = new System.Drawing.Point(146, 154);
            this.lblMaxPersonasA.Name = "lblMaxPersonasA";
            this.lblMaxPersonasA.Size = new System.Drawing.Size(96, 18);
            this.lblMaxPersonasA.TabIndex = 48;
            this.lblMaxPersonasA.Text = "Max Personas:";
            // 
            // txtbxIDA
            // 
            this.txtbxIDA.Location = new System.Drawing.Point(278, 175);
            this.txtbxIDA.Name = "txtbxIDA";
            this.txtbxIDA.Size = new System.Drawing.Size(100, 20);
            this.txtbxIDA.TabIndex = 47;
            // 
            // lblIDA
            // 
            this.lblIDA.AutoSize = true;
            this.lblIDA.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDA.Location = new System.Drawing.Point(275, 154);
            this.lblIDA.Name = "lblIDA";
            this.lblIDA.Size = new System.Drawing.Size(26, 18);
            this.lblIDA.TabIndex = 46;
            this.lblIDA.Text = "ID:";
            // 
            // txtbxPuertoA
            // 
            this.txtbxPuertoA.Location = new System.Drawing.Point(149, 87);
            this.txtbxPuertoA.Name = "txtbxPuertoA";
            this.txtbxPuertoA.Size = new System.Drawing.Size(100, 20);
            this.txtbxPuertoA.TabIndex = 45;
            // 
            // lblPuertoA
            // 
            this.lblPuertoA.AutoSize = true;
            this.lblPuertoA.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPuertoA.Location = new System.Drawing.Point(146, 66);
            this.lblPuertoA.Name = "lblPuertoA";
            this.lblPuertoA.Size = new System.Drawing.Size(54, 18);
            this.lblPuertoA.TabIndex = 44;
            this.lblPuertoA.Text = "Puerto:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(275, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 18);
            this.label1.TabIndex = 42;
            this.label1.Text = "Fecha de Regreso:";
            // 
            // lblFechaSalidaA
            // 
            this.lblFechaSalidaA.AutoSize = true;
            this.lblFechaSalidaA.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaSalidaA.Location = new System.Drawing.Point(12, 110);
            this.lblFechaSalidaA.Name = "lblFechaSalidaA";
            this.lblFechaSalidaA.Size = new System.Drawing.Size(106, 18);
            this.lblFechaSalidaA.TabIndex = 40;
            this.lblFechaSalidaA.Text = "Fecha de Salida:";
            // 
            // txtbxCostoA
            // 
            this.txtbxCostoA.Location = new System.Drawing.Point(12, 175);
            this.txtbxCostoA.Name = "txtbxCostoA";
            this.txtbxCostoA.Size = new System.Drawing.Size(100, 20);
            this.txtbxCostoA.TabIndex = 39;
            // 
            // lblCostoA
            // 
            this.lblCostoA.AutoSize = true;
            this.lblCostoA.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoA.Location = new System.Drawing.Point(12, 154);
            this.lblCostoA.Name = "lblCostoA";
            this.lblCostoA.Size = new System.Drawing.Size(109, 18);
            this.lblCostoA.TabIndex = 38;
            this.lblCostoA.Text = "Costo individual:";
            // 
            // txtbxDestinoA
            // 
            this.txtbxDestinoA.Location = new System.Drawing.Point(12, 87);
            this.txtbxDestinoA.Name = "txtbxDestinoA";
            this.txtbxDestinoA.Size = new System.Drawing.Size(100, 20);
            this.txtbxDestinoA.TabIndex = 37;
            // 
            // lblDestinoA
            // 
            this.lblDestinoA.AutoSize = true;
            this.lblDestinoA.Font = new System.Drawing.Font("Corbel", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestinoA.Location = new System.Drawing.Point(9, 66);
            this.lblDestinoA.Name = "lblDestinoA";
            this.lblDestinoA.Size = new System.Drawing.Size(59, 18);
            this.lblDestinoA.TabIndex = 36;
            this.lblDestinoA.Text = "Destino:";
            // 
            // txtbxResActualesA
            // 
            this.txtbxResActualesA.Location = new System.Drawing.Point(12, 473);
            this.txtbxResActualesA.Multiline = true;
            this.txtbxResActualesA.Name = "txtbxResActualesA";
            this.txtbxResActualesA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtbxResActualesA.Size = new System.Drawing.Size(582, 89);
            this.txtbxResActualesA.TabIndex = 34;
            // 
            // btnUsuario
            // 
            this.btnUsuario.BackColor = System.Drawing.Color.Transparent;
            this.btnUsuario.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUsuario.BackgroundImage")));
            this.btnUsuario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnUsuario.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsuario.ForeColor = System.Drawing.Color.White;
            this.btnUsuario.Location = new System.Drawing.Point(600, 1);
            this.btnUsuario.Margin = new System.Windows.Forms.Padding(0);
            this.btnUsuario.Name = "btnUsuario";
            this.btnUsuario.Size = new System.Drawing.Size(118, 31);
            this.btnUsuario.TabIndex = 33;
            this.btnUsuario.Text = "Usuario";
            this.btnUsuario.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnUsuario.UseVisualStyleBackColor = false;
            this.btnUsuario.Click += new System.EventHandler(this.btnUsuario_Click);
            // 
            // picBanda
            // 
            this.picBanda.Image = ((System.Drawing.Image)(resources.GetObject("picBanda.Image")));
            this.picBanda.Location = new System.Drawing.Point(2, 1);
            this.picBanda.Name = "picBanda";
            this.picBanda.Size = new System.Drawing.Size(730, 31);
            this.picBanda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBanda.TabIndex = 6;
            this.picBanda.TabStop = false;
            // 
            // ProyectoFinal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 642);
            this.Controls.Add(this.picSearch);
            this.Controls.Add(this.txtbxSearch);
            this.Controls.Add(this.picIcon);
            this.Controls.Add(this.lblSevenSeas);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProyectoFinal";
            this.Text = "Seven Seas - Sistema de Reservación";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBeach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBorderMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabUsuario.ResumeLayout(false);
            this.tabUsuario.PerformLayout();
            this.tabAdmin.ResumeLayout(false);
            this.tabAdmin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBanda)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSevenSeas;
        private System.Windows.Forms.PictureBox picBeach;
        private System.Windows.Forms.PictureBox picIcon;
        private System.Windows.Forms.TextBox txtbxSearch;
        private System.Windows.Forms.PictureBox picSearch;
        private System.Windows.Forms.PictureBox picBorderMenu;
        private System.Windows.Forms.Button btnCrucerosDisponibles;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblCuando;
        private System.Windows.Forms.DateTimePicker calCalendario;
        private System.Windows.Forms.Label lblDonde;
        private System.Windows.Forms.ComboBox cmbDestinos;
        private System.Windows.Forms.TextBox txtbxReservarCruc;
        private System.Windows.Forms.Label lblReservarCrucero;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtbxNumTarjeta;
        private System.Windows.Forms.Label lblNumPasajeros;
        private System.Windows.Forms.TextBox txtbxNumPasajeros;
        private System.Windows.Forms.Button btnFiltrar;
        private System.Windows.Forms.Label lblNumTarjeta;
        private System.Windows.Forms.TextBox txtbxNombre;
        private System.Windows.Forms.Label lblConfirmacion;
        private System.Windows.Forms.Label lblListaCruceros;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.ListBox lstbxLista;
        private System.Windows.Forms.ListBox lstbxConfirmacion;
        private System.Windows.Forms.CheckBox chkboxFecha;
        private System.Windows.Forms.Button btnReservar;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabUsuario;
        private System.Windows.Forms.TabPage tabAdmin;
        private System.Windows.Forms.Button btnUsuario;
        private System.Windows.Forms.PictureBox picBanda;
        private System.Windows.Forms.TextBox txtbxDestinoA;
        private System.Windows.Forms.Label lblDestinoA;
        private System.Windows.Forms.TextBox txtbxResActualesA;
        private System.Windows.Forms.TextBox txtbxCostoA;
        private System.Windows.Forms.Label lblCostoA;
        private System.Windows.Forms.Label lblFechaSalidaA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbxPuertoA;
        private System.Windows.Forms.Label lblPuertoA;
        private System.Windows.Forms.TextBox txtbxMaxPersonasA;
        private System.Windows.Forms.Label lblMaxPersonasA;
        private System.Windows.Forms.TextBox txtbxIDA;
        private System.Windows.Forms.Label lblIDA;
        private System.Windows.Forms.Button btnGuardarA;
        private System.Windows.Forms.Label lblResActualesA;
        private System.Windows.Forms.DateTimePicker calRegresoA;
        private System.Windows.Forms.DateTimePicker calSalidaA;
        private System.Windows.Forms.Label lblDardeAltaA;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox lstbxListaBajaA;
        private System.Windows.Forms.Label lblDardeBajaA;
    }
}

