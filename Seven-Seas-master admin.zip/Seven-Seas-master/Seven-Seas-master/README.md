# Seven-Seas
One of the two final projects of the "Software Engineering Fundamentals" class.
